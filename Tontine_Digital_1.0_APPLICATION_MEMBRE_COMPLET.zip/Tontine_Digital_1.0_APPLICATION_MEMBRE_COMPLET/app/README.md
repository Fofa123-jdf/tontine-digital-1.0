# Tontine Digital 1.0 — Application membre
Interface mobile vierge, avec accueil de marque, menus illustrés, 12 écrans, navigation séquentielle, inscription/connexion locales et états vides.

Publication web : placer le contenu de `app/` à la racine du dépôt GitHub Pages.

La version actuelle est une démo web : aucun paiement réel, aucun backend centralisé et aucune donnée fictive préchargée. Le backend et le schéma PostgreSQL fournis dans ce package constituent la base de développement suivante.
