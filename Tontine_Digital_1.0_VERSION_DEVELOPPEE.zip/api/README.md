# Tontine Digital 1.0 — API

Backend Node.js/Express + PostgreSQL. Aucun jeu de données fictif n'est inclus.

## Règle financière finale
Pour la première cotisation d'un membre dans une tontine : base + 1% administration + 1% parrain valide. Les cotisations suivantes : base seule. Exemple 500 FCFA + 5 + 5 = 510 FCFA avec parrain valide.

## Démarrage
1. Copier `.env.example` vers `.env` et renseigner les secrets/DB.
2. Créer PostgreSQL puis exécuter `db/schema.sql`.
3. `npm install && npm start`.

Le mode `manual` permet de préparer des paiements sans prétendre qu'un transfert externe a eu lieu. Les références et confirmations viennent ensuite du prestataire ou de l'administrateur.
