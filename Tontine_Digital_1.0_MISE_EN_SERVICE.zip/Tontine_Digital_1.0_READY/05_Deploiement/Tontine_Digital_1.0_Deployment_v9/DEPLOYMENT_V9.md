# Tontine Digital 1.0 — Deployment v9

Cette version prépare le projet pour un déploiement serveur avec Node.js + PostgreSQL.

## 1. Test local avec Docker

Depuis ce dossier :

```bash
docker compose up -d --build
```

API :
- http://localhost:3002/health

Pour arrêter :

```bash
docker compose down
```

Les données PostgreSQL restent dans le volume Docker `tontine_db`.

## 2. Avant une mise en production

Remplacer impérativement :
- `JWT_SECRET`
- le mot de passe PostgreSQL
- `CORS_ORIGIN`
- les secrets de paiement

Ne pas mettre les clés de paiement dans l'application mobile.

## 3. HTTPS

En production, placer l'API derrière un domaine HTTPS et un reverse proxy ou le HTTPS fourni par l'hébergeur.

Exemple :
- API : `https://api.votre-domaine.ci`
- application membre : `https://app.votre-domaine.ci`
- administration : `https://admin.votre-domaine.ci`

## 4. Base PostgreSQL

Créer la base puis exécuter la migration SQL du projet avant le premier usage.

Vérifier ensuite :

```text
GET /health
```

## 5. Paiements

Le serveur crée les transactions en `PENDING`.
La confirmation finale doit venir du serveur du prestataire via webhook/API.

Ne jamais considérer une simple réponse JavaScript du téléphone comme preuve définitive de paiement.

## 6. Wave

Le projet contient déjà la structure de webhook sécurisée et l'adaptateur Wave du v7/v8.

Pour passer en réel, il faut encore :
- un compte marchand/business compatible ;
- les identifiants/API keys ;
- l'URL HTTPS publique du webhook ;
- la configuration exacte du compte ;
- un test de paiement réel puis une vérification de rapprochement.

Les clés restent uniquement côté serveur.

## 7. MTN / Orange / Moov

Les adaptateurs restent configurables. Les identifiants marchands et paramètres exacts doivent être fournis par chaque opérateur avant activation réelle.

## 8. Sécurité minimale

- HTTPS obligatoire en production.
- JWT secret long et aléatoire.
- PostgreSQL non exposé publiquement.
- Sauvegardes régulières de la base.
- Journalisation des webhooks et transactions.
- Idempotence des événements de paiement.
- Accès admin limité aux comptes administrateurs.

## 9. Prochaine étape

Une fois l'hébergement choisi et les accès marchands disponibles, configurer :
1. domaine HTTPS ;
2. PostgreSQL production ;
3. variables d'environnement ;
4. migration ;
5. compte administrateur initial ;
6. Wave en premier ;
7. tests de paiement ;
8. activation progressive des autres opérateurs.
