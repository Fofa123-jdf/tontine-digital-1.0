# Checklist de mise en production

- [ ] Domaine API configuré
- [ ] HTTPS actif
- [ ] PostgreSQL production créé
- [ ] Sauvegardes PostgreSQL configurées
- [ ] JWT_SECRET changé
- [ ] Mot de passe DB changé
- [ ] CORS limité aux domaines de l'application
- [ ] Compte admin créé
- [ ] Webhook Wave HTTPS configuré
- [ ] Secret webhook Wave configuré
- [ ] Paiement test validé
- [ ] Confirmation webhook validée
- [ ] Reçu généré après confirmation
- [ ] Commission administration vérifiée
- [ ] Commission parrain vérifiée
- [ ] Notifications testées
- [ ] Accès membre/admin vérifiés
