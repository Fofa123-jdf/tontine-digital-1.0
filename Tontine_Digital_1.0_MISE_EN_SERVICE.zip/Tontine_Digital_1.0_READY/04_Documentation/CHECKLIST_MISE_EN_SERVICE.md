# TONTINE DIGITAL 1.0 — CHECKLIST DE MISE EN SERVICE

## Déjà préparé
- Application membre
- Espace administration séparé
- Backend/API commun
- PostgreSQL
- Journal/ledger
- Workflow des paiements
- Webhook de paiement prévu
- Préparation Android/Capacitor
- Documentation
- Règle financière Option A

## À connecter avec les comptes du propriétaire
1. Hébergement de production
2. PostgreSQL de production
3. Domaine + HTTPS
4. Clés marchandes/API Wave
5. Clés/API Orange Money
6. Clés/API MTN Money
7. Clés/API Moov Money
8. Webhooks de production
9. Clé de signature Android
10. Compte Google Play Console

## Avant ouverture au public
- Tester une inscription
- Tester une première cotisation avec parrain
- Vérifier 500 -> 510 FCFA
- Vérifier une première cotisation sans parrain
- Vérifier 500 -> 505 FCFA
- Vérifier une deuxième cotisation -> 500 FCFA
- Vérifier le journal
- Tester une confirmation webhook
- Tester un paiement bénéficiaire
- Tester les notifications
- Tester les droits admin/membre
- Sauvegarder PostgreSQL
- Vérifier les journaux d'audit

NE PAS considérer l'application comme une plateforme d'argent réel tant que les comptes marchands, le serveur de production et les tests de bout en bout n'ont pas été réalisés.
