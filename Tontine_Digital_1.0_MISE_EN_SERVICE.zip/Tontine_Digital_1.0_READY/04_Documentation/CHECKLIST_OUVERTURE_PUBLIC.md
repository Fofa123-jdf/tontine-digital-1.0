# CHECKLIST — OUVERTURE AU PUBLIC

## Code
- [x] Application membre
- [x] Administration séparée
- [x] Backend/API
- [x] PostgreSQL/schema
- [x] Règle financière Option A
- [x] Journal/ledger
- [x] Webhook Wave préparé
- [x] Android preparation

## Comptes externes
- [ ] Serveur de production
- [ ] Domaine HTTPS
- [ ] PostgreSQL production
- [ ] Wave Business/API
- [ ] Orange Money marchand/API
- [ ] MTN Money/API
- [ ] Webhooks enregistrés
- [ ] Tests de paiement réels
- [ ] Sauvegardes
- [ ] Clé de signature Android
- [ ] AAB signé
- [ ] Publication Google Play

## Règle d'or
Ne jamais considérer un paiement comme confirmé à partir de l'écran du téléphone.
Seule la confirmation fournisseur côté serveur valide la transaction.
