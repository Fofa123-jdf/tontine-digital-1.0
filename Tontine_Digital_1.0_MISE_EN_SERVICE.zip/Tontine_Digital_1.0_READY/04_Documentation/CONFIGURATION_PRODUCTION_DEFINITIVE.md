# MISE EN SERVICE — TONTINE DIGITAL 1.0

## 1. Configuration financière définitive

Monnaie : XOF / FCFA.

### Cotisation d'entrée
Pour une première cotisation dans une tontine :
- Cotisation = montant fixé par la tontine
- Commission administration = 1 %
- Commission parrain = 1 % uniquement si un code parrain valide est associé
- Les commissions sont AJOUTÉES au montant de la cotisation.

Exemples :
- 500 FCFA + parrain = 510 FCFA
- 500 FCFA sans parrain = 505 FCFA
- 1 000 FCFA + parrain = 1 020 FCFA

### Cotisations suivantes
Aucune commission :
- 500 FCFA reste 500 FCFA
- 1 000 FCFA reste 1 000 FCFA

Le serveur est la seule source de vérité pour les calculs.

## 2. Comptes de collecte

Les comptes personnels/numéros réels ne sont pas écrits dans le code, Git ou les documents publics.

À configurer côté serveur :
- WAVE_COLLECTION_ACCOUNT
- ORANGE_COLLECTION_ACCOUNT
- MTN_COLLECTION_ACCOUNT

Le même numéro peut être associé à plusieurs canaux lorsque le fournisseur le permet, mais chaque canal doit avoir sa propre configuration API/merchant.

## 3. Architecture de paiement

Membre
→ création de commande
→ paiement chez le fournisseur
→ webhook sécurisé
→ vérification serveur
→ transaction CONFIRMED
→ journal financier
→ reçu
→ affichage membre/admin.

Un écran mobile ne doit jamais confirmer lui-même un paiement.

## 4. Wave

Le compte doit être un Wave Business pour utiliser les API Business. Les clés API doivent rester uniquement sur le serveur. La documentation officielle Wave confirme également les API de réception de paiements, de solde, de rapprochement et de payout.

Variables serveur :
WAVE_API_KEY=
WAVE_WEBHOOK_SECRET=
WAVE_API_BASE_URL=https://api.wave.com

Webhook :
WAVE_WEBHOOK_URL=https://VOTRE-DOMAINE/webhooks/wave

## 5. Orange Money

L'intégration Web Payment/M Payment nécessite un compte marchand Orange Money et l'accès API correspondant. Les identifiants sont fournis après validation/inscription auprès d'Orange.

Variables serveur à compléter selon les identifiants fournis :
ORANGE_MERCHANT_ID=
ORANGE_CLIENT_ID=
ORANGE_CLIENT_SECRET=
ORANGE_API_BASE_URL=
ORANGE_WEBHOOK_SECRET=

## 6. MTN Money

Créer/faire approuver l'application dans le portail développeur MTN et renseigner les clés du produit activé.

Variables :
MTN_API_KEY=
MTN_API_SECRET=
MTN_SUBSCRIPTION_KEY=
MTN_API_BASE_URL=
MTN_TARGET_ENVIRONMENT=
MTN_CALLBACK_URL=

## 7. Sécurité

Ne jamais mettre :
- clé API
- secret webhook
- mot de passe
- JWT secret
- clé privée

dans l'application Android, le JavaScript public, Git ou ce ZIP.

Utiliser les variables d'environnement du serveur.

## 8. Mise en production

À fournir/configurer hors du code :
1. serveur avec HTTPS ;
2. PostgreSQL de production ;
3. domaine ;
4. compte Wave Business + clés ;
5. compte Orange Money marchand + accès API ;
6. accès MTN Money/API ;
7. webhooks HTTPS ;
8. tests réels de faible montant ;
9. rapprochement des transactions ;
10. sauvegardes PostgreSQL.

## 9. Test de réception

Avant toute ouverture au public :

Test A :
500 + parrain → 510.

Test B :
500 sans parrain → 505.

Test C :
deuxième cotisation de 500 → 500.

Test D :
webhook envoyé deux fois → une seule transaction financière.

Test E :
montant modifié côté client → refus serveur.

Test F :
paiement échoué → aucune cotisation confirmée et aucune commission créée.

## 10. Paiement bénéficiaire

La plateforme prépare automatiquement l'ordre de paiement.
L'administration valide.
Le paiement est ensuite exécuté via le fournisseur autorisé.
La référence fournisseur est enregistrée.
Le journal financier est mis à jour.
Le membre reçoit son statut/reçu.

L'approbation administrative ne doit jamais être considérée comme une sortie d'argent tant que le fournisseur n'a pas confirmé le paiement.

## 11. Important — fonds réels

Le logiciel peut suivre et rapprocher les fonds, mais l'autorisation de recevoir/conserver et redistribuer l'argent de membres dépend du statut du compte marchand, du fournisseur de paiement et des règles applicables en Côte d'Ivoire.

Avant ouverture publique, faire valider le montage de collecte et de redistribution avec les prestataires de paiement et, si nécessaire, un conseil juridique/réglementaire local.
