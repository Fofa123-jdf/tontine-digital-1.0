# REGLE FINANCIERE DEFINITIVE — TONTINE DIGITAL 1.0

## Option A — commissions ajoutées au montant de la première cotisation

La commission est appliquée uniquement à la première cotisation d'un membre dans une tontine.

- Cotisation : montant fixé par la tontine
- Commission administration : 1 % de la cotisation
- Commission parrain : 1 % si un code parrain valide est associé
- Les commissions sont ajoutées au montant payé par le membre.
- Les cotisations suivantes n'ont aucune commission.

### Formules

Avec parrain :
TOTAL = COTISATION + 1 % administration + 1 % parrain
TOTAL = COTISATION × 1,02

Sans parrain :
TOTAL = COTISATION + 1 % administration
TOTAL = COTISATION × 1,01

### Exemples

| Cotisation | Parrain | Admin | Parrain | Total |
|---:|:---:|---:|---:|---:|
| 500 FCFA | Oui | 5 | 5 | 510 FCFA |
| 500 FCFA | Non | 5 | 0 | 505 FCFA |
| 1 000 FCFA | Oui | 10 | 10 | 1 020 FCFA |
| 1 000 FCFA | Non | 10 | 0 | 1 010 FCFA |
| 5 000 FCFA | Oui | 50 | 50 | 5 100 FCFA |
| 5 000 FCFA | Non | 50 | 0 | 5 050 FCFA |
| 10 000 FCFA | Oui | 100 | 100 | 10 200 FCFA |
| 10 000 FCFA | Non | 100 | 0 | 10 100 FCFA |
| 20 000 FCFA | Oui | 200 | 200 | 20 400 FCFA |
| 20 000 FCFA | Non | 200 | 0 | 20 200 FCFA |

IMPORTANT : pour une première cotisation, le montant de cotisation versé à la tontine reste le montant de base. Les commissions sont des lignes séparées dans le journal financier.

Les règles doivent être recalculées et validées côté serveur. L'application mobile ne doit jamais être la source d'autorité pour les montants.
