# TONTINE DIGITAL 1.0 — MANUEL COMPLET DU PROJET

## 1. Objectif
Tontine Digital 1.0 est une solution de gestion de tontines composée de deux applications distinctes :
- Application Membre ;
- Application Administration.

Elles utilisent un backend/API commun et une base PostgreSQL.

## 2. Application Membre
- inscription / connexion ;
- profil ;
- adhésion aux tontines ;
- cotisations et historique ;
- reçus ;
- calendrier et prochain tour ;
- notifications ;
- code parrain ;
- espace d'échange organisé par tontine.

## 3. Administration
- tableau de bord ;
- gestion des membres et tontines ;
- suivi des cotisations ;
- commissions ;
- comptes de collecte ;
- paiements des bénéficiaires ;
- journal financier ;
- rapprochement ;
- notifications ;
- rapports ;
- audit.

## 4. Paiements des membres
Flux : membre → API → prestataire → webhook/confirmation serveur → PostgreSQL → grand livre → reçu.

Statuts : PENDING, CONFIRMED, FAILED, EXPIRED, REFUNDED.
Une référence fournisseur ne doit jamais être créditée deux fois.

## 5. Commissions
Règle métier :
- 1 % administration sur la première cotisation du membre dans une tontine ;
- 1 % parrain valide sur cette même première cotisation ;
- 0 % sur les cotisations suivantes.

Exemple : 500 FCFA → 5 FCFA administration + 5 FCFA parrain lorsque le parrain est valide.
Le mode final de facturation (frais ajoutés au montant ou déduits de la cotisation) doit être fixé avant la production financière.

## 6. Gestion des fonds
Les comptes physiques de collecte peuvent être bancaires ou mobile money. Le logiciel tient une comptabilité logique séparée par tontine et par nature de fonds :
- TONTINE_FUNDS ;
- ADMIN_COMMISSION ;
- SPONSOR_COMMISSION ;
- REFUND.

Les soldes doivent être dérivés des écritures. Une correction crée une nouvelle écriture au lieu de modifier l'historique.

## 7. Paiement des bénéficiaires
Le backend prépare automatiquement un ordre avant l'échéance avec nom, téléphone, tontine, tour, montant, date, fournisseur et compte source.

Alertes par défaut : J-7, J-3, J-1 et J0.

Cycle :
SCHEDULED → PREPARED → PENDING_ADMIN_VALIDATION → APPROVED → PAYMENT_IN_PROGRESS → PAID → CONFIRMED.

L'approbation de l'ordre ne signifie pas que l'argent est déjà transféré. Dans la première version, l'administrateur réalise le transfert dans l'application du prestataire, saisit la référence et confirme le paiement.

## 8. Sécurité
- HTTPS en production ;
- JWT ;
- rôles member/admin/super_admin ;
- secrets uniquement côté serveur ;
- validation serveur ;
- idempotence ;
- références fournisseur uniques ;
- audit ;
- validation des signatures webhook lorsque prévues ;
- sauvegardes PostgreSQL ;
- aucune route d'administration accessible aux membres.

## 9. API principale
POST /api/auth/register
POST /api/auth/login
GET /api/me
POST /api/tontines/:tontineId/join
POST /api/payments/preview
POST /api/payments
GET /api/payments/:id/receipt
GET /api/admin/overview
GET /api/admin/tontines
GET /api/admin/collection-accounts
GET /api/admin/beneficiary-payments
POST /api/admin/beneficiary-payments/:id/approve
POST /api/admin/beneficiary-payments/:id/reject
POST /api/admin/beneficiary-payments/:id/mark-paid
POST /api/admin/beneficiary-payments/:id/confirm
GET /api/admin/ledger
POST /webhooks/wave

## 10. Déploiement
Architecture cible :
app.domaine.tld → application membre
admin.domaine.tld → administration
api.domaine.tld → backend
PostgreSQL → base de données

Variables à configurer :
PORT, JWT_SECRET, DATABASE_URL, DATABASE_SSL, DB_POOL_MAX, CORS_ORIGIN, WAVE_API_KEY, WAVE_WEBHOOK_SECRET, WAVE_API_BASE_URL et les paramètres marchands Orange/MTN/Moov.

## 11. Procédure quotidienne
1. Vérifier le tableau de bord.
2. Contrôler les cotisations en attente.
3. Vérifier les prochaines échéances.
4. Contrôler les ordres bénéficiaires.
5. Valider les ordres.
6. Effectuer les transferts.
7. Saisir les références.
8. Confirmer les paiements.
9. Vérifier le journal et le rapprochement.
10. Traiter les écarts.

## 12. Mise en production
Le projet est préparé pour le déploiement, mais l'utilisation avec de l'argent réel nécessite encore la configuration réelle du serveur, domaine HTTPS, PostgreSQL, comptes marchands, clés API et webhooks, ainsi que des tests de bout en bout.

Avant ouverture au public :
- tester inscription et connexion ;
- tester adhésion ;
- tester paiement ;
- tester webhook ;
- tester doublon ;
- tester remboursement ;
- tester ordre bénéficiaire ;
- tester rapprochement ;
- tester sauvegarde/restauration ;
- vérifier les droits admin/membre ;
- valider le montage financier avec les partenaires compétents.

## 13. Principe important
Ne jamais mettre de vraies clés API, mots de passe ou secrets dans le code source ou l'application mobile. Utiliser les variables d'environnement du serveur.

## 14. État final
Le package regroupe les versions les plus avancées disponibles du membre, de l'administration, du backend et du déploiement, avec la documentation finale. Les éléments dépendant d'identifiants et de comptes externes restent à renseigner avant la mise en production réelle.
