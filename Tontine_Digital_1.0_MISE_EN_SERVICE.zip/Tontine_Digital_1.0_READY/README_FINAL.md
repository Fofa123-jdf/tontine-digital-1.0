# Tontine Digital 1.0 — Final
Deux applications séparées, un backend commun et PostgreSQL.
Voir 04_Documentation/MANUEL_COMPLET_TONTINE_DIGITAL_1.0.md.
