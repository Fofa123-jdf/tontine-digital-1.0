# TONTINE DIGITAL 1.0 — PACKAGE PRÊT POUR MISE EN SERVICE

Le package regroupe :
- application membre ;
- administration séparée ;
- backend/API commun ;
- PostgreSQL ;
- déploiement Docker ;
- documentation ;
- préparation Android/Google Play.

## Ce qui reste obligatoirement externe
Pour rendre le service réellement public et traiter de l'argent réel, il faut encore :
1. créer/choisir le compte d'hébergement ;
2. créer le domaine et HTTPS ;
3. créer/configurer PostgreSQL de production ;
4. renseigner les vraies clés marchandes Wave/Orange/MTN/Moov ;
5. configurer les webhooks ;
6. tester les paiements réels en environnement autorisé ;
7. créer la clé de signature Android ;
8. générer et tester le `.aab` ;
9. créer/configurer le compte Google Play Console ;
10. publier après validation Google.

Ces actions nécessitent des comptes, identifiants, moyens de paiement ou validations externes que le package ne peut pas créer à la place du propriétaire.
