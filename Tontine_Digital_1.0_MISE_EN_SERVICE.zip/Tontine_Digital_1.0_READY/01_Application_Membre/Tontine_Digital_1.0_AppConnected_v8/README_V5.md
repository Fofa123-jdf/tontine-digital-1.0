# Tontine Digital 1.0 — Backend réel v5

Cette version ajoute le premier branchement technique entre l'application, l'API et le modèle de données.

Inclus:
- schéma PostgreSQL;
- authentification JWT + bcrypt;
- inscription avec code parrain;
- connexion;
- profil;
- adhésion à une tontine;
- calcul de première cotisation;
- création d'une transaction PENDING;
- reçu après confirmation;
- routes d'administration;
- exemples de clients API mobile/admin.

Avant production:
1. connecter PostgreSQL;
2. brancher les webhooks réels Wave/MTN/Orange;
3. ajouter vérification de signature et idempotence persistante;
4. configurer HTTPS, secrets et sauvegardes;
5. remplacer le dépôt mémoire par le repository PostgreSQL;
6. connecter SMS/voix.
