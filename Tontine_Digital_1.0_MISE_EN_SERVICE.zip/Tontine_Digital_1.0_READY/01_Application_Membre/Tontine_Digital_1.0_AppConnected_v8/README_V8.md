# Tontine Digital 1.0 — App Connected v8

Cette version relie les interfaces membre et administration à l'API PostgreSQL v7.

## Démarrage API
1. `cd backend`
2. `npm install`
3. Copier `.env.example` vers `.env`
4. Renseigner `DATABASE_URL`, `JWT_SECRET` et `CORS_ORIGIN`
5. Créer/migrer la base avec `backend/schema.sql` puis `backend/db/migration.sql`
6. `npm start`

## Interfaces
- Membre : `mobile/index.html`
- Administration : `admin/index.html`

Par défaut, les interfaces appellent `http://localhost:3002`.
Pour une API distante, avant chargement de la page, définir `window.TONTINE_API_BASE_URL` dans un petit fichier de configuration ou remplacer la valeur par votre domaine HTTPS.

## Important
Le paiement est créé en base avec le statut PENDING. La confirmation réelle doit venir du webhook de l'opérateur. Cette v8 ne prétend pas avoir connecté des comptes marchands réels ni généré un checkout opérateur sans identifiants de production.

## Tests
- `npm test` dans `backend` pour les tests disponibles.
