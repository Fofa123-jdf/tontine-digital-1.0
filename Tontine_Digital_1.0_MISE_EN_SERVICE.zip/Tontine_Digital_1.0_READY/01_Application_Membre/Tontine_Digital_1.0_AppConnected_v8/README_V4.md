# Tontine Digital 1.0 — Interface App + Admin v4

Cette version ajoute:
- interface membre mobile;
- calcul visuel de la première cotisation;
- espace d'échanges limité à la tontine;
- interface Super Admin;
- préparation des écrans de paiements, reçus, membres, tontines, notifications et rapports.

Les données sont encore des données de démonstration. La connexion à l'API/backend et aux opérateurs doit être faite avant toute utilisation réelle.
