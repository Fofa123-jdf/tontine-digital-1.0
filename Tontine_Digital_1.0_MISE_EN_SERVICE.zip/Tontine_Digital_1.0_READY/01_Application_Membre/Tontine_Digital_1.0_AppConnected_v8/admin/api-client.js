const API_BASE_URL = (window.TONTINE_API_BASE_URL || "http://localhost:3002").replace(/\/$/, "");
async function request(path, options={}) {
  const token=localStorage.getItem("tontine_admin_token");
  const headers={...(options.body?{"Content-Type":"application/json"}:{}),...(options.headers||{})};
  if(token) headers.Authorization=`Bearer ${token}`;
  const r=await fetch(`${API_BASE_URL}${path}`,{...options,headers});
  const data=await r.json().catch(()=>({}));
  if(!r.ok) throw new Error(data.error||`Erreur HTTP ${r.status}`);
  return data;
}
export const adminApi={
  login:(phone,password)=>request("/api/auth/login",{method:"POST",body:JSON.stringify({phone,password})}),
  overview:()=>request("/api/admin/overview"),
  createTontine:(name,contributionAmount,frequency="monthly")=>request("/api/admin/tontines",{method:"POST",body:JSON.stringify({name,contributionAmount,frequency})})
};
