import crypto from "node:crypto";
import { calculateFirstContribution } from "./payment-rules.js";

export function createPendingPayment({ userId, tontineId, amount, hasValidReferrer, provider }) {
  const breakdown = calculateFirstContribution(amount, hasValidReferrer);
  return {
    id: crypto.randomUUID(),
    userId,
    tontineId,
    provider,
    baseAmount: breakdown.amount,
    adminFee: breakdown.adminFee,
    referralFee: breakdown.referralFee,
    totalAmount: breakdown.total,
    status: "PENDING",
    createdAt: new Date().toISOString()
  };
}

export function confirmPayment(payment, providerReference) {
  if (payment.status === "CONFIRMED") {
    return { payment, alreadyConfirmed: true };
  }
  if (!providerReference) throw new Error("Référence opérateur obligatoire");
  return {
    payment: {
      ...payment,
      providerReference,
      status: "CONFIRMED",
      confirmedAt: new Date().toISOString()
    },
    alreadyConfirmed: false
  };
}
