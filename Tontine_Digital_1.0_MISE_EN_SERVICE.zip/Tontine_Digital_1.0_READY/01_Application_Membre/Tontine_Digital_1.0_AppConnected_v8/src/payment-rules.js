export function calculateFirstContribution(amount, hasValidReferrer) {
  if (!Number.isInteger(amount) || amount <= 0) throw new Error("Montant invalide");
  const adminFee = Math.floor(amount * 0.01);
  const referralFee = hasValidReferrer ? Math.floor(amount * 0.01) : 0;
  return { amount, adminFee, referralFee, total: amount + adminFee + referralFee };
}
