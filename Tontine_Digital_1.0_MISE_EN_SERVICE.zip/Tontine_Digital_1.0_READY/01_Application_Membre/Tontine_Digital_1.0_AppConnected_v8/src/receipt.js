export function buildReceipt(payment) {
  if (payment.status !== "CONFIRMED") throw new Error("Reçu disponible après confirmation");
  return {
    receiptNumber: `TD-${payment.id.slice(0, 8).toUpperCase()}`,
    paymentId: payment.id,
    amount: payment.baseAmount,
    adminFee: payment.adminFee,
    referralFee: payment.referralFee,
    totalPaid: payment.totalAmount,
    provider: payment.provider,
    providerReference: payment.providerReference,
    confirmedAt: payment.confirmedAt
  };
}
