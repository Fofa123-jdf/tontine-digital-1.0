// Adaptateur MTN MoMo.
// Les endpoints/credentials exacts sont chargés depuis .env après ouverture du compte développeur.
// Ne jamais mettre les secrets dans l'application mobile.

export async function createMtnRequestToPay(config) {
  if (!config.baseUrl || !config.apiKey || !config.subscriptionKey) {
    throw new Error("Configuration MTN MoMo incomplète");
  }
  throw new Error("Adaptateur MTN prêt pour configuration des endpoints/identifiants du compte.");
}
