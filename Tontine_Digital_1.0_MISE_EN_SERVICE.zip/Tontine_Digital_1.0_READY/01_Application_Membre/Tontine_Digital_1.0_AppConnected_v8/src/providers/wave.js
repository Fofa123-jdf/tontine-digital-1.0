const jsonHeaders = (apiKey) => ({
  Authorization: `Bearer ${apiKey}`,
  "Content-Type": "application/json"
});

export async function createWaveCheckout({ apiKey, baseUrl="https://api.wave.com",
  amount, clientReference, successUrl, errorUrl }) {
  if (!apiKey) throw new Error("WAVE_API_KEY manquante");
  const response = await fetch(`${baseUrl}/v1/checkout/sessions`, {
    method: "POST",
    headers: jsonHeaders(apiKey),
    body: JSON.stringify({
      amount: String(amount),
      currency: "XOF",
      client_reference: clientReference,
      success_url: successUrl,
      error_url: errorUrl
    })
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`Wave HTTP ${response.status}: ${JSON.stringify(data)}`);
  return data;
}
