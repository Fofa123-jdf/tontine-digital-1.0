// Adaptateur Orange Money CI.
// Les endpoints et secrets exacts doivent provenir du contrat/API Orange Business du compte marchand.

export async function createOrangePayment(config) {
  if (!config.baseUrl || !config.clientId || !config.clientSecret) {
    throw new Error("Configuration Orange Money incomplète");
  }
  throw new Error("Adaptateur Orange prêt pour configuration des endpoints/identifiants du compte.");
}
