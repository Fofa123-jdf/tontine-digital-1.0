import express from "express";
import dotenv from "dotenv";
import crypto from "node:crypto";
import { calculateFirstContribution } from "./payment-rules.js";
import { createWaveCheckout } from "./providers/wave.js";

dotenv.config();
const app = express();

// Webhook Wave: conserver le corps brut pour une vérification correcte de signature.
app.post("/webhooks/wave", express.raw({ type: "application/json" }), (req, res) => {
  const secret = process.env.WAVE_WEBHOOK_SECRET;
  const signature = req.header("Wave-Signature");

  if (!secret || !signature) return res.status(401).send("Webhook non configuré");

  // La validation exacte de signature doit suivre le format Wave-Signature
  // et le secret de signature du compte Business.
  // TODO: implémenter la validation HMAC complète avant production.

  let event;
  try { event = JSON.parse(req.body.toString("utf8")); }
  catch { return res.status(400).send("JSON invalide"); }

  // TODO: idempotence par event.id, puis confirmation atomique en base.
  console.log("Wave webhook reçu:", event.id, event.type);
  return res.sendStatus(200);
});

app.use(express.json());

app.post("/api/payments/preview", (req, res) => {
  try {
    const { amount, hasValidReferrer } = req.body;
    res.json(calculateFirstContribution(Number(amount), Boolean(hasValidReferrer)));
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.post("/api/payments/wave/checkout", async (req, res) => {
  try {
    const { amount, hasValidReferrer, clientReference } = req.body;
    const breakdown = calculateFirstContribution(Number(amount), Boolean(hasValidReferrer));

    const checkout = await createWaveCheckout({
      apiKey: process.env.WAVE_API_KEY,
      baseUrl: process.env.WAVE_API_BASE_URL,
      amount: breakdown.total,
      clientReference: clientReference || crypto.randomUUID(),
      successUrl: process.env.WAVE_SUCCESS_URL,
      errorUrl: process.env.WAVE_ERROR_URL
    });

    res.status(201).json({ breakdown, checkout });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true, service: "tontine-digital-payments" }));

const port = Number(process.env.PORT || 3001);
app.listen(port, () => console.log(`Payment API on :${port}`));
