# Tontine Digital 1.0 — PostgreSQL v6

Cette version ajoute la couche PostgreSQL réelle:
- pool PostgreSQL sécurisé;
- repository pour utilisateurs, tontines et paiements;
- migrations et index;
- contrainte d'idempotence des événements de paiement;
- gestion transactionnelle de confirmation;
- configuration `.env`.

Le serveur API doit encore être basculé entièrement du dépôt mémoire vers le repository PostgreSQL avant production.
