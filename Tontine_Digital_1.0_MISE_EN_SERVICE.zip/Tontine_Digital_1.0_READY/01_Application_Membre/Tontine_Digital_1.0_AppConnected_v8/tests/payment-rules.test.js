import test from "node:test";
import assert from "node:assert/strict";
import { calculateFirstContribution } from "../src/payment-rules.js";

test("500 avec parrain = 510", () => {
  assert.deepEqual(calculateFirstContribution(500, true), {
    amount: 500, adminFee: 5, referralFee: 5, total: 510
  });
});

test("500 sans parrain = 505", () => {
  assert.deepEqual(calculateFirstContribution(500, false), {
    amount: 500, adminFee: 5, referralFee: 0, total: 505
  });
});

test("1000 avec parrain = 1020", () => {
  assert.equal(calculateFirstContribution(1000, true).total, 1020);
});
