import test from "node:test";
import assert from "node:assert/strict";
import { createPendingPayment, confirmPayment } from "../src/payment-flow.js";

test("crée une transaction en attente avec les frais", () => {
  const p = createPendingPayment({
    userId: "u1", tontineId: "t1", amount: 500,
    hasValidReferrer: true, provider: "wave"
  });
  assert.equal(p.totalAmount, 510);
  assert.equal(p.status, "PENDING");
});

test("une confirmation répétée ne recrée pas la cotisation", () => {
  const p = {
    id: "p1", status: "CONFIRMED", baseAmount: 500,
    adminFee: 5, referralFee: 5, totalAmount: 510
  };
  const result = confirmPayment(p, "wave-ref-1");
  assert.equal(result.alreadyConfirmed, true);
});
