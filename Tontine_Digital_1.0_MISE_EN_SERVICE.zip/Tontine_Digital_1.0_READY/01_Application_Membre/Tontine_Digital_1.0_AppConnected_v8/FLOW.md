# Parcours complet de paiement — Tontine Digital 1.0

1. Inscription du membre
2. Attribution d'un code parrain unique
3. Le membre rejoint une tontine avec éventuellement un code parrain
4. Le serveur vérifie le parrain et l'adhésion
5. Le serveur détermine si c'est la première cotisation de ce membre dans cette tontine
6. Calcul:
   - cotisation de base
   - +1% administration si première cotisation
   - +1% parrain si première cotisation et parrain valide
7. Création d'une transaction avec statut PENDING
8. Redirection vers le moyen de paiement
9. L'opérateur confirme côté serveur via webhook
10. Le serveur vérifie la signature et l'identifiant unique de l'événement
11. La transaction passe à CONFIRMED une seule fois
12. La cotisation est enregistrée
13. Les commissions sont enregistrées séparément
14. Un reçu est généré
15. Notification du membre
16. Le tableau d'administration est mis à jour

Important: une URL de retour mobile réussie ne suffit jamais à confirmer une transaction.
