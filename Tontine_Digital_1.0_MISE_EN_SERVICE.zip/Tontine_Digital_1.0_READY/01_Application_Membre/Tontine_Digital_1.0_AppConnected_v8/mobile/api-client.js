const API_BASE_URL = (window.TONTINE_API_BASE_URL || "http://localhost:3002").replace(/\/$/, "");

async function request(path, options = {}) {
  const token = localStorage.getItem("tontine_token");
  const headers = { ...(options.body ? {"Content-Type":"application/json"} : {}), ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const r = await fetch(`${API_BASE_URL}${path}`, {...options, headers});
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Erreur HTTP ${r.status}`);
  return data;
}
export const api = {
  register: (fullName, phone, password, referralCode="") =>
    request("/api/auth/register", {method:"POST", body:JSON.stringify({fullName, phone, password, referralCode})}),
  login: (phone, password) =>
    request("/api/auth/login", {method:"POST", body:JSON.stringify({phone, password})}),
  me: () => request("/api/me"),
  join: (tontineId) => request(`/api/tontines/${encodeURIComponent(tontineId)}/join`, {method:"POST"}),
  previewPayment: (tontineId, amount) =>
    request("/api/payments/preview", {method:"POST", body:JSON.stringify({tontineId, amount})}),
  createPayment: (tontineId, amount, provider) =>
    request("/api/payments", {method:"POST", body:JSON.stringify({tontineId, amount, provider})}),
  receipt: (paymentId) => request(`/api/payments/${encodeURIComponent(paymentId)}/receipt`)
};
