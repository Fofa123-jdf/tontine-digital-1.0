# Tontine Digital 1.0 — Paiement multi-opérateurs v2

Cette version prépare l'intégration réelle de Wave, MTN MoMo et Orange Money.

## Architecture
Application mobile -> API Tontine Digital -> fournisseur de paiement -> webhook fournisseur -> API -> base de données.

Les clés API ne doivent jamais être placées dans l'application mobile.

## Règle de commission
- Première cotisation confirmée dans une tontine: administration 1%.
- Parrain valide: parrain 1% supplémentaire.
- Cotisations suivantes: 0% de ces commissions.
- Exemple 500 F avec parrain = 510 F.

## Fournisseurs
### Wave
Le module contient un adaptateur Checkout utilisant l'API Business officielle Wave.
Variables: WAVE_API_KEY, WAVE_API_BASE_URL, WAVE_SUCCESS_URL, WAVE_ERROR_URL.
Le webhook doit vérifier la signature et être idempotent.

### MTN MoMo
Structure d'adaptateur prévue pour Collection / RequestToPay.
Il faut renseigner les identifiants et paramètres du compte développeur MTN.

### Orange Money
Structure d'adaptateur prévue pour l'API Orange Money Côte d'Ivoire.
Il faut renseigner les identifiants/API fournis par Orange Business.

## Installation
npm install
cp .env.example .env
npm start

Aucune transaction réelle ne doit être activée avant les tests sandbox et la validation des comptes marchands.


## Parcours complet v3
Le fichier FLOW.md décrit le parcours inscription -> adhésion -> paiement -> webhook -> confirmation -> reçu -> notification.
Les modules `src/payment-flow.js` et `src/receipt.js` fournissent la base métier.
