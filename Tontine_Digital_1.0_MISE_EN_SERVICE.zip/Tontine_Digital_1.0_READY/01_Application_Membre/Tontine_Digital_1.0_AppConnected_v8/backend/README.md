# Backend réel v5

Routes principales:
POST /api/auth/register
POST /api/auth/login
GET /api/me
POST /api/tontines/:tontineId/join
POST /api/payments/preview
POST /api/payments
GET /api/payments/:id/receipt
GET /api/admin/overview
POST /api/admin/tontines

Le serveur fourni utilise un dépôt mémoire pour permettre un démarrage local immédiat. `schema.sql` contient le schéma PostgreSQL destiné à remplacer ce dépôt avant production.

La confirmation réelle d'un paiement doit rester basée sur le webhook signé du fournisseur, jamais sur une simple réponse de l'application.
