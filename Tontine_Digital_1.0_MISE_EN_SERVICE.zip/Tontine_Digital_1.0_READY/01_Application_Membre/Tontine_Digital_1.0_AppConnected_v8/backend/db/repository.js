import { pool } from "./pool.js";

export async function findUserByPhone(phone) {
  const r = await pool.query("SELECT * FROM users WHERE phone=$1 LIMIT 1", [phone]);
  return r.rows[0] || null;
}

export async function findUserByReferralCode(code) {
  if (!code) return null;
  const r = await pool.query("SELECT id FROM users WHERE referral_code=$1 LIMIT 1", [code]);
  return r.rows[0] || null;
}

export async function createUser({fullName, phone, passwordHash, referralCode, referredBy}) {
  const r = await pool.query(
    `INSERT INTO users(full_name,phone,password_hash,referral_code,referred_by)
     VALUES($1,$2,$3,$4,$5)
     RETURNING id,full_name,phone,referral_code,referred_by,role,created_at`,
    [fullName,phone,passwordHash,referralCode,referredBy]
  );
  return r.rows[0];
}

export async function getUser(id) {
  const r = await pool.query(
    "SELECT id,full_name,phone,referral_code,referred_by,role,created_at FROM users WHERE id=$1",
    [id]
  );
  return r.rows[0] || null;
}

export async function getTontine(id) {
  const r = await pool.query("SELECT * FROM tontines WHERE id=$1", [id]);
  return r.rows[0] || null;
}

export async function isMember(tontineId, userId) {
  const r = await pool.query(
    "SELECT 1 FROM tontine_members WHERE tontine_id=$1 AND user_id=$2",
    [tontineId,userId]
  );
  return r.rowCount > 0;
}

export async function hasConfirmedContribution(tontineId, userId) {
  const r = await pool.query(
    "SELECT 1 FROM payments WHERE tontine_id=$1 AND user_id=$2 AND status='CONFIRMED' LIMIT 1",
    [tontineId,userId]
  );
  return r.rowCount > 0;
}

export async function createPayment(p) {
  const r = await pool.query(
    `INSERT INTO payments
      (user_id,tontine_id,provider,base_amount,admin_fee,referral_fee,total_amount,status,is_first_contribution)
     VALUES($1,$2,$3,$4,$5,$6,$7,'PENDING',$8)
     RETURNING *`,
    [p.userId,p.tontineId,p.provider,p.baseAmount,p.adminFee,p.referralFee,p.totalAmount,p.isFirstContribution]
  );
  return r.rows[0];
}

export async function confirmPaymentByProviderReference(provider, providerReference) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const r = await client.query(
      "SELECT * FROM payments WHERE provider=$1 AND provider_reference=$2 FOR UPDATE",
      [provider,providerReference]
    );
    if (!r.rowCount) throw new Error("Paiement introuvable");
    const payment = r.rows[0];
    if (payment.status !== "CONFIRMED") {
      await client.query(
        "UPDATE payments SET status='CONFIRMED', confirmed_at=NOW() WHERE id=$1",
        [payment.id]
      );
    }
    await client.query("COMMIT");
    return {...payment,status:"CONFIRMED"};
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

export async function saveProviderEvent({paymentId,provider,providerEventId,eventType,payload}) {
  const r = await pool.query(
    `INSERT INTO payment_events(payment_id,provider,provider_event_id,event_type,payload)
     VALUES($1,$2,$3,$4,$5)
     ON CONFLICT(provider,provider_event_id) DO NOTHING
     RETURNING id`,
    [paymentId,provider,providerEventId,eventType,payload]
  );
  return r.rowCount > 0;
}

export async function overview() {
  const [users,tontines,payments,confirmed,pending] = await Promise.all([
    pool.query("SELECT COUNT(*)::int AS n FROM users"),
    pool.query("SELECT COUNT(*)::int AS n FROM tontines"),
    pool.query("SELECT COUNT(*)::int AS n FROM payments"),
    pool.query("SELECT COUNT(*)::int AS n FROM payments WHERE status='CONFIRMED'"),
    pool.query("SELECT COUNT(*)::int AS n FROM payments WHERE status='PENDING'")
  ]);
  return {
    members: users.rows[0].n,
    tontines: tontines.rows[0].n,
    payments: payments.rows[0].n,
    confirmedPayments: confirmed.rows[0].n,
    pendingPayments: pending.rows[0].n
  };
}
