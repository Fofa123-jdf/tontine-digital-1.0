# PostgreSQL v6

## Mise en place

1. Créer une base PostgreSQL `tontine_digital`.
2. Exécuter `db/migration.sql`.
3. Copier `.env.example` vers `.env`.
4. Renseigner `DATABASE_URL`.
5. Installer les dépendances: `npm install`.
6. Démarrer: `npm start`.

## Important

Le fichier `db/repository.js` contient les opérations PostgreSQL principales.
Le serveur v5 conserve encore le dépôt mémoire pour compatibilité de démonstration; avant production, ses appels doivent être remplacés par ces fonctions repository.

Pour les paiements, les événements fournisseur utilisent une contrainte unique `(provider, provider_event_id)` afin qu'un même webhook ne soit pas traité deux fois.
