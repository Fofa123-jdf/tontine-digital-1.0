import test from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";

test("Wave HMAC signing payload is timestamp + raw body",()=>{
 const secret="test-secret",ts=1700000000,body='{"id":"EV1","type":"checkout.session.completed"}';
 const sig=crypto.createHmac("sha256",secret).update(String(ts)+body).digest("hex");
 assert.equal(sig.length,64);
});
