# Production Backend v7

L'API principale utilise maintenant PostgreSQL via `db/repository.js`.
Le dépôt mémoire de v5 n'est plus utilisé par `server.js`.

## Déploiement
1. Créer PostgreSQL.
2. Exécuter `db/migration.sql`.
3. Configurer `.env`.
4. `npm install`
5. `npm start`
6. Vérifier `/health`.

## Webhook Wave
Le webhook utilise le corps HTTP brut, vérifie `Wave-Signature`, contrôle la fenêtre temporelle et déduplique l'ID d'événement. Wave documente cette méthode HMAC-SHA256 et recommande la signature pour la production.

## MTN et Orange
Les routes/adaptateurs restent séparés tant que les identifiants et contrats API du compte marchand ne sont pas fournis. Aucun endpoint ou mécanisme de signature non vérifié n'est inventé.

## Production
Mettre HTTPS, secrets hors dépôt Git, sauvegardes PostgreSQL, rotation des secrets, logs sans données sensibles, et tests de bout en bout avant d'accepter de vrais paiements.
