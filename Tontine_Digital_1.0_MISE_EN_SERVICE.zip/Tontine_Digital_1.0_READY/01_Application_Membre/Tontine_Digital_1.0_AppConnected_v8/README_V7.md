# Tontine Digital 1.0 — Production Backend v7

Version préparée pour:
- API entièrement branchée sur PostgreSQL;
- authentification et gestion des membres;
- tontines et adhésions;
- paiements persistants;
- idempotence des événements;
- webhook Wave signé et anti-rejeu;
- administration.

Les informations officielles Wave indiquent que les webhooks doivent être reçus en HTTPS, que les doublons doivent être gérés, et que la signature HMAC avec `Wave-Signature` peut être utilisée pour sécuriser les webhooks. citeturn0search1turn0search0

MTN et Orange restent configurables, mais leurs mécanismes exacts de webhook/signature ne sont pas inventés dans cette version: ils devront être branchés selon les credentials et spécifications délivrés pour le compte marchand.
