# Tontine Digital 1.0 — Préparation Android / Google Play

Cette partie prépare l'application membre Web existante à être empaquetée en application Android avec Capacitor.

## Identifiant
`ci.tontinedigital.app`

## Cible Google Play
Android 16 / API 36 minimum pour la soumission d'une nouvelle application à Google Play à compter du 31 août 2026.

## Préparation
Dans ce dossier :

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

Puis dans Android Studio :
- vérifier `compileSdk = 36` et `targetSdk = 36` ou supérieur ;
- configurer l'icône et le nom de l'application ;
- créer la clé de signature de production ;
- configurer la signature Release ;
- vérifier l'URL HTTPS de l'API de production ;
- construire le fichier `.aab` Release.

## Important
Le fichier `.aab` ne peut pas être généré ici sans l'environnement Android/Gradle, la clé de signature de production et la configuration finale du serveur. Le projet contient cependant la configuration nécessaire pour effectuer cette étape.

## Production
Architecture recommandée :
- application membre : `app.<domaine>`
- administration : `admin.<domaine>`
- API : `api.<domaine>`
- PostgreSQL : service privé

Le backend ne doit jamais contenir de secrets dans l'application Android.
