#!/usr/bin/env bash
set -e
npm install
npx cap add android
npx cap sync android
echo "Projet Android généré. Ouvrez ensuite Android Studio et configurez la signature Release."
