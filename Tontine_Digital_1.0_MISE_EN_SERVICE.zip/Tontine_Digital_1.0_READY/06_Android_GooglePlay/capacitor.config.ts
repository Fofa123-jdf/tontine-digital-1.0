import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'ci.tontinedigital.app',
  appName: 'Tontine Digital',
  webDir: '../01_Application_Membre/Tontine_Digital_1.0_AppConnected_v8/mobile',
  server: {
    androidScheme: 'https'
  }
};

export default config;
