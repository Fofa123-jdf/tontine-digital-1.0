import express from "express";
import dotenv from "dotenv";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { pool, checkDatabase } from "./db/pool.js";
import * as repo from "./db/repository.js";

dotenv.config();
const app=express();
const PORT=Number(process.env.PORT||3002);
const JWT_SECRET=process.env.JWT_SECRET;
if(!JWT_SECRET) throw new Error("JWT_SECRET manquant");

function tokenFor(u){return jwt.sign({sub:u.id,role:u.role},JWT_SECRET,{expiresIn:"7d"});}
function auth(req,res,next){const h=req.headers.authorization||""; if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Authentification requise"}); try{req.auth=jwt.verify(h.slice(7),JWT_SECRET);next()}catch{return res.status(401).json({error:"Token invalide"})}}
function adminOnly(req,res,next){if(!["admin","super_admin"].includes(req.auth.role)) return res.status(403).json({error:"Accès administrateur requis"});next();}
function referralCode(){return "TD-"+crypto.randomBytes(4).toString("hex").toUpperCase();}
function fees(amount,hasRef){const admin=Math.floor(amount*.01), ref=hasRef?Math.floor(amount*.01):0; return {baseAmount:amount,adminFee:admin,referralFee:ref,totalAmount:amount+admin+ref};}

app.get("/health",async(_req,res)=>{try{const r=await checkDatabase();res.json({ok:true,database:"connected",time:r.now,version:"v7"})}catch(e){res.status(503).json({ok:false,database:"unavailable"})}});

app.post("/api/auth/register",async(req,res)=>{
 try{
  const {fullName,phone,password,referralCode:ref}=req.body;
  if(!fullName||!phone||!password)return res.status(400).json({error:"Nom, téléphone et mot de passe requis"});
  if(await repo.findUserByPhone(phone))return res.status(409).json({error:"Numéro déjà utilisé"});
  const sponsor=await repo.findUserByReferralCode(ref);
  const user=await repo.createUser({fullName,phone,passwordHash:await bcrypt.hash(password,12),referralCode:referralCode(),referredBy:sponsor?.id||null});
  res.status(201).json({user,token:tokenFor(user)});
 }catch(e){res.status(500).json({error:"Erreur serveur"})}
});

app.post("/api/auth/login",async(req,res)=>{
 try{const u=await repo.findUserByPhone(req.body.phone);if(!u||!(await bcrypt.compare(req.body.password||"",u.password_hash)))return res.status(401).json({error:"Identifiants incorrects"});res.json({token:tokenFor(u),user:{id:u.id,fullName:u.full_name,phone:u.phone,referralCode:u.referral_code,role:u.role}})}
 catch{res.status(500).json({error:"Erreur serveur"})}
});

app.get("/api/me",auth,async(req,res)=>{const u=await repo.getUser(req.auth.sub);if(!u)return res.status(404).json({error:"Utilisateur introuvable"});res.json(u)});

app.post("/api/tontines/:tontineId/join",auth,async(req,res)=>{
 const t=await repo.getTontine(req.params.tontineId); if(!t||t.status!=="active")return res.status(404).json({error:"Tontine indisponible"});
 if(await repo.isMember(t.id,req.auth.sub))return res.status(409).json({error:"Déjà membre"});
 await pool.query("INSERT INTO tontine_members(tontine_id,user_id) VALUES($1,$2)",[t.id,req.auth.sub]);
 res.status(201).json({ok:true,tontine:t});
});

app.post("/api/payments/preview",auth,async(req,res)=>{
 const amount=Number(req.body.amount),tontineId=req.body.tontineId;
 if(!Number.isInteger(amount)||amount<=0)return res.status(400).json({error:"Montant invalide"});
 if(!(await repo.isMember(tontineId,req.auth.sub)))return res.status(403).json({error:"Membre requis"});
 const first=!(await repo.hasConfirmedContribution(tontineId,req.auth.sub));
 const u=await repo.getUser(req.auth.sub);
 res.json({firstContribution:first,...(first?fees(amount,Boolean(u.referred_by)):{baseAmount:amount,adminFee:0,referralFee:0,totalAmount:amount})});
});

app.post("/api/payments",auth,async(req,res)=>{
 try{
  const amount=Number(req.body.amount),tontineId=req.body.tontineId,provider=req.body.provider;
  if(!["wave","mtn","orange"].includes(provider))return res.status(400).json({error:"Opérateur non supporté"});
  if(!(await repo.isMember(tontineId,req.auth.sub)))return res.status(403).json({error:"Membre requis"});
  const first=!(await repo.hasConfirmedContribution(tontineId,req.auth.sub));
  const u=await repo.getUser(req.auth.sub);
  const b=first?fees(amount,Boolean(u.referred_by)):{baseAmount:amount,adminFee:0,referralFee:0,totalAmount:amount};
  const p=await repo.createPayment({userId:req.auth.sub,tontineId,provider,...b,isFirstContribution:first});
  res.status(201).json({payment:p,nextStep:"PROVIDER_CHECKOUT"});
 }catch(e){res.status(400).json({error:e.message})}
});

app.get("/api/payments/:id/receipt",auth,async(req,res)=>{
 const r=await pool.query("SELECT * FROM payments WHERE id=$1 AND user_id=$2 AND status='CONFIRMED'",[req.params.id,req.auth.sub]);
 if(!r.rowCount)return res.status(404).json({error:"Reçu disponible après confirmation"});
 const p=r.rows[0];res.json({receiptNumber:"TD-"+p.id.slice(0,8).toUpperCase(),...p});
});

app.get("/api/admin/overview",auth,adminOnly,async(_req,res)=>res.json(await repo.overview()));

app.post("/api/admin/tontines",auth,adminOnly,async(req,res)=>{
 const {name,contributionAmount,frequency="monthly"}=req.body;
 const r=await pool.query("INSERT INTO tontines(name,contribution_amount,frequency) VALUES($1,$2,$3) RETURNING *",[name,Number(contributionAmount),frequency]);
 res.status(201).json(r.rows[0]);
});

// Wave webhook uses raw body so signature verification is valid.
app.post("/webhooks/wave",express.raw({type:"application/json"}),async(req,res)=>{
 const secret=process.env.WAVE_WEBHOOK_SECRET;
 const header=req.get("Wave-Signature")||"";
 if(!secret)return res.status(503).send("Webhook not configured");
 const parts=Object.fromEntries(header.split(",").map(x=>x.split("=").length===2?x.split("="):["",""]));
 const ts=Number(parts.t);
 const sig=parts.v1;
 if(!Number.isFinite(ts)||!sig)return res.status(401).send("Invalid signature");
 const age=Math.floor(Date.now()/1000)-ts;
 if(age>300||age<-30)return res.status(401).send("Expired signature");
 const expected=crypto.createHmac("sha256",secret).update(String(ts)+req.body.toString("utf8")).digest("hex");
 if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(sig)))return res.status(401).send("Invalid signature");
 let event;try{event=JSON.parse(req.body.toString("utf8"))}catch{return res.status(400).send("Invalid JSON")}
 const inserted=await repo.saveProviderEvent({paymentId:null,provider:"wave",providerEventId:event.id,eventType:event.type,payload:event});
 if(!inserted)return res.sendStatus(200);
 const data=event.data||{};
 const providerRef=data.client_reference||data.transaction_id||data.id;
 if(providerRef){
   const r=await pool.query("SELECT id FROM payments WHERE provider='wave' AND (id::text=$1 OR provider_reference=$1) LIMIT 1",[providerRef]);
   if(r.rowCount) await pool.query("UPDATE payments SET provider_reference=$1,status='CONFIRMED',confirmed_at=NOW() WHERE id=$2 AND status='PENDING'",[providerRef,r.rows[0].id]);
 }
 return res.sendStatus(200);
});

app.listen(PORT,()=>console.log(`Tontine Digital API v7 :${PORT}`));
