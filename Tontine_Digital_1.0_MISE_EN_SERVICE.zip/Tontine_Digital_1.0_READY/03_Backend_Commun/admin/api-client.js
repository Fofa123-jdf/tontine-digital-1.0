const API_BASE_URL = "https://VOTRE-DOMAINE-API";

export async function getOverview(token) {
  const r = await fetch(`${API_BASE_URL}/api/admin/overview`, {
    headers:{Authorization:`Bearer ${token}`}
  });
  return r.json();
}
