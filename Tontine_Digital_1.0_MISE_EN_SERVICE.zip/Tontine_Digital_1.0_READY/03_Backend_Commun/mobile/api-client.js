const API_BASE_URL = "https://VOTRE-DOMAINE-API";

export async function register(fullName, phone, password, referralCode) {
  const r = await fetch(`${API_BASE_URL}/api/auth/register`, {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({fullName,phone,password,referralCode})
  });
  return r.json();
}

export async function previewPayment(token, tontineId, amount) {
  const r = await fetch(`${API_BASE_URL}/api/payments/preview`, {
    method:"POST", headers:{"Content-Type":"application/json","Authorization":`Bearer ${token}`},
    body:JSON.stringify({tontineId,amount})
  });
  return r.json();
}
